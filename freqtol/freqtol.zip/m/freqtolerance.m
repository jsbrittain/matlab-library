function analysis = freqtolerance( dat, fc, fbandwidth, rate, precision, rejectmode )

analysis = freqtolerance_timeseries( dat, fc, fbandwidth, rate, precision, rejectmode );
